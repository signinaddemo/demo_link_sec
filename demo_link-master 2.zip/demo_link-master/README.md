# ad_demo

1. 找到想要換圖的 demo link 檔案，打開後複製裡面全部的程式碼
2. 回到專案首頁點擊上面的 Add file -> Create new file
3. 貼上剛剛複製的程式碼，並且命名檔案為 **新的數字**.html
4. 找到程式碼裡面的 body，然後改掉裡面圖片路徑的數字，改成**新的數字**
5. 找到程式碼裡面的 window.open，把後面的 url 換成想要導連的連結
6. 改完數字還有連結後，按最下面的 Commit new file 送出
7. 回到專案首頁點擊進入 images 資料夾
8. 點擊上面的 Add file -> Upload files
9. 在自己的電腦創建一個新的資料夾，檔名為**新的數字**，然後把素材放進去資料夾裡面，素材檔名須符合 html 檔裡面的圖片路徑
10. 點擊下方的 Commit changes 送出
11. 完成以上步驟即可打開 <https://signinaddemo.github.io/demo_link/XX.html> 查看 demo link（把 xx 換成**新的數字**）
